@echo off
title GTFS Apple HeadSign Manager v2.10.1
cd /d "%~dp0"
py headsign_manager.py
pause
