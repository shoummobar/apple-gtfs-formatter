GTFS Apple HeadSign Manager v2.10.0

Workflow
1. Put all Google-ready GTFS ZIP files in Base GTFS.
2. Run Avvia_Manager.bat.
3. Click AGGIORNA MAPPATURA.
4. In Mappa_Headsign.xlsx edit only Apple overrides when needed.
5. Close Excel.
6. Click GENERA APPLE.

Headsign casing
The default Apple headsign is conservative: only the leading municipality prefix written in ALL CAPS is converted to Title Case. The rest of the Google trip_headsign is preserved exactly, apart from Italian vowel-apostrophe normalization (for example CANTU' -> CANTÙ). This avoids damaging service abbreviations or destination text.

Stop names
Default Apple stop_name preserves the original GTFS casing. Only Italian vowel-apostrophe forms are normalized (for example CANTU' -> CANTÙ, Cantu' -> Cantù). Apple stop_name overrides remain available.

Bindings
HeadSign and stop bindings persist across feed replacement/renaming when their stable key remains resolvable. Historical bindings are kept in the workbook.

Terminal stop
For each trip_headsign, the manager selects the last stop of each trip by the highest stop_sequence, then chooses the most frequent terminal stop among those trips. Maps links use coordinates only.

Headsign engine v2.10.0: municipality-only Title Case inferred from the leading ALL-CAPS municipality prefixes found in stop names; the remaining headsign text is preserved exactly.
