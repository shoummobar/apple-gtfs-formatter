
from __future__ import annotations
import csv, io, os, re, shutil, sys, time, zipfile, unicodedata
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

# Excel automation is intentional: the manager runs on Windows with Excel installed.
try:
    import win32com.client as win32
except Exception:
    win32 = None

ROOT = Path(__file__).resolve().parent
BASE_DIR = ROOT / "Base GTFS"
APPLE_DIR = ROOT / "Apple"
ARCHIVE_DIR = APPLE_DIR / "Archivio"
XLSX = ROOT / "Mappa_Headsign.xlsx"

VERSION = "2.9.1"

HEADSIGN_HEADERS = [
    "Google trip_headsign","Apple trip_headsign (Override)","Default Apple · Title Case",
    "Fermata terminale più frequente","Lat","Lon","Maps","Stato","Prima rilevazione",
    "Ultima rilevazione","Note","Binding Key"
]
STOP_HEADERS = [
    "Stop Binding Key","Stop ID","Nome originale","Default Apple stop_name","Apple stop_name (Override)",
    "Lat","Lon","Maps","Stato","Feed","Occorrenze terminali","Note"
]
HISTORY_HEADERS = ["Timestamp","Azione","Binding Key","Google trip_headsign","Apple Override","Default Apple","Stato"]
FEED_GROUP_HEADERS = ["Google trip_headsign","Apple trip_headsign (Override)","Default Apple · Title Case","Fermata terminale più frequente","Lat","Lon","Maps","Stato","Prima rilevazione","Ultima rilevazione","Note","Binding Key"]


ACRONYMS = {
    "FN","FS","FNM","IIS","ISIS","ITS","STPS","CAI","SS","SP",
    "TPL","ATM","ATB","SIA","SAI","SAF","STIE","APAM","ARRIVA",
}
LOWER_WORDS = {
    "a","ad","al","allo","alla","ai","agli","alle",
    "da","dal","dallo","dalla","dai","dagli","dalle",
    "di","del","dello","della","dei","degli","delle",
    "in","nel","nello","nella","nei","negli","nelle",
    "su","sul","sullo","sulla","sui","sugli","sulle",
    "e","ed","o",
}
# 'per' is intentionally NOT here: user wants "Per Fornaci".
COMMON_ROMAN_WORD_EXCLUSIONS = LOWER_WORDS | {"di", "id"}

def accent_apostrophe(text: str) -> str:
    """CANTU' -> CANTÙ, Cantu' -> Cantù, without touching normal contractions like L'APRICA."""
    if not text:
        return text
    def repl(m):
        ch = m.group(1)
        apost = m.group(2)
        mp = {"A":"À","E":"È","I":"Ì","O":"Ò","U":"Ù","a":"à","e":"è","i":"ì","o":"ò","u":"ù"}
        return mp[ch]
    return re.sub(r"([AEIOUaeiou])(['’])(?=$|[\s,.;:!?()\[\]{}\/\\-])", repl, text)

def normalize_spaces(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())

def canonical(text: str) -> str:
    """Stable key for bindings: case, accents/apostrophe style, whitespace and Unicode punctuation normalized."""
    text = accent_apostrophe(text or "")
    text = text.replace("’","'").replace("`","'")
    text = normalize_spaces(text)
    text = unicodedata.normalize("NFKC", text)
    return text.casefold()

def is_roman(token: str) -> bool:
    t = re.sub(r"[^A-Za-z]", "", token or "").upper()
    if len(t) < 2 or t.casefold() in COMMON_ROMAN_WORD_EXCLUSIONS:
        return False
    if not re.fullmatch(r"[IVXLCDM]+", t):
        return False
    # Require a normal Roman-numeral-looking sequence.
    return bool(re.fullmatch(r"M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})", t))

def title_case_token(token: str) -> str:
    if not token:
        return token

    # Always-lowercase abbreviation requested by user.
    if re.fullmatch(r"fr\.", token, flags=re.I):
        return "fr."

    # Single-letter abbreviation or initial followed by a period:
    # A., O., S., M., S.Fermo, S.Anna, etc.
    m = re.match(r"^([A-Za-z])\.(.+)$", token)
    if m:
        return m.group(1).upper() + "." + title_case_token(m.group(2))
    if re.fullmatch(r"[A-Za-z]\.", token):
        return token[0].upper() + "."

    # Preserve highway abbreviations like SS 45 / SP510 when they arrive as one token.
    if re.fullmatch(r"(SS|SP)\.?[-/]?\d+[A-Za-z]?", token, flags=re.I):
        m = re.match(r"([A-Za-z]+)(.*)", token)
        return m.group(1).upper() + m.group(2)

    # Acronyms explicitly configured.
    letters_only = re.sub(r"[^A-Za-z]", "", token)
    if letters_only.casefold() in {x.casefold() for x in ACRONYMS} and letters_only:
        out = ""
        seen = 0
        for ch in token:
            if ch.isalpha():
                out += letters_only.upper()[seen]
                seen += 1
            else:
                out += ch
        return out

    # Roman numerals such as XXV, XX, IV, XII; common words such as DI are excluded.
    if is_roman(token):
        return token.upper()

    # Lowercase Italian connector words. 'per' is intentionally not included.
    plain = re.sub(r"[^\wÀ-ÿ']", "", token, flags=re.UNICODE)
    if plain.casefold() in LOWER_WORDS:
        return plain.casefold() + token[len(plain):]

    # Handle apostrophe-separated names while keeping contractions readable.
    parts = token.split("'")
    if len(parts) > 1:
        return "'".join(title_case_token(p) if p else p for p in parts)

    return token[:1].upper() + token[1:].lower()

def smart_title_case(text: str) -> str:
    text = accent_apostrophe(normalize_spaces(text or ""))
    # Normalize fr. even when attached to punctuation.
    parts = re.split(r"(\s+)", text)
    return "".join(title_case_token(p) if not p.isspace() else p for p in parts)

def normalize_stop_name(text: str) -> str:
    """Backward-compatible alias: stop names use the exact same smart formatter as headsigns."""
    return smart_title_case(text)

def maps_url(lat, lon) -> str:
    if lat in (None, "", "None") or lon in (None, "", "None"):
        return ""
    try:
        la = float(lat)
        lo = float(lon)
    except Exception:
        return ""
    return f"https://www.google.com/maps/search/?api=1&query={la:.7f},{lo:.7f}"

def parse_float(v):
    try:
        return float(str(v).strip().replace(",", "."))
    except Exception:
        return None

def parse_seq(v):
    try:
        return float(v)
    except Exception:
        return None

def zip_text(zf, name):
    raw = zf.read(name)
    return raw.decode("utf-8-sig", errors="replace")

def read_csv_from_zip(zf, name):
    with io.StringIO(zip_text(zf, name), newline="") as f:
        reader = csv.DictReader(f)
        return list(reader), reader.fieldnames or []

def list_feeds():
    return sorted([p for p in BASE_DIR.iterdir() if p.is_file() and p.suffix.lower() == ".zip"], key=lambda p: p.name.casefold())

def stop_key(feed_name, stop_id, lat, lon):
    la, lo = parse_float(lat), parse_float(lon)
    if la is not None and lo is not None:
        # Physical stop binding: survives replacement/renaming of the GTFS file and stop_name.
        return f"COORD:{la:.6f},{lo:.6f}"
    return f"STOPID:{feed_name.casefold()}::{str(stop_id).strip()}"

def collect_gtfs():
    feeds = list_feeds()
    if not feeds:
        raise RuntimeError(f"Nessun ZIP trovato in: {BASE_DIR}")

    stops = {}                 # key -> info
    stop_local = {}            # (feed, stop_id) -> key
    headsign_display = {}      # canonical -> first display
    headsign_trips = defaultdict(list)  # canonical -> trip composite ids
    terminal_counts = defaultdict(Counter)  # headsign canon -> stop key counter
    trip_info = {}

    for feed in feeds:
        feed_name = feed.name
        with zipfile.ZipFile(feed, "r") as z:
            names = set(z.namelist())
            required = {"trips.txt", "stop_times.txt", "stops.txt"}
            missing = [x for x in required if x not in names]
            if missing:
                raise RuntimeError(f"{feed_name}: mancano {', '.join(missing)}")

            stop_rows, _ = read_csv_from_zip(z, "stops.txt")
            for r in stop_rows:
                sid = str(r.get("stop_id","")).strip()
                if not sid:
                    continue
                lat = parse_float(r.get("stop_lat",""))
                lon = parse_float(r.get("stop_lon",""))
                key = stop_key(feed_name, sid, lat, lon)
                stop_local[(feed_name, sid)] = key
                info = stops.setdefault(key, {
                    "stop_id": sid,
                    "original_name": r.get("stop_name",""),
                    "default_name": smart_title_case(r.get("stop_name", "")),
                    "lat": lat, "lon": lon,
                    "feeds": set(),
                })
                info["feeds"].add(feed_name)
                # Prefer a populated coordinate/name if an earlier duplicate was sparse.
                if not info["original_name"] and r.get("stop_name"):
                    info["original_name"] = r.get("stop_name")
                if info["lat"] is None and lat is not None:
                    info["lat"] = lat
                if info["lon"] is None and lon is not None:
                    info["lon"] = lon

            trip_rows, _ = read_csv_from_zip(z, "trips.txt")
            for r in trip_rows:
                tid = str(r.get("trip_id","")).strip()
                hs = str(r.get("trip_headsign","")).strip()
                if not tid:
                    continue
                hk = canonical(hs)
                headsign_display.setdefault(hk, hs)
                comp = (feed_name, tid)
                trip_info[comp] = {"headsign_key": hk, "headsign_display": hs}
                headsign_trips[hk].append(comp)

            # Find actual terminal stop for every trip: max stop_sequence; fallback to file order.
            trip_last = {}
            with io.StringIO(zip_text(z, "stop_times.txt"), newline="") as f:
                reader = csv.DictReader(f)
                order = 0
                for r in reader:
                    order += 1
                    tid = str(r.get("trip_id","")).strip()
                    if not tid or (feed_name, tid) not in trip_info:
                        continue
                    sid = str(r.get("stop_id","")).strip()
                    skey = stop_local.get((feed_name, sid))
                    if not skey:
                        continue
                    seq = parse_seq(r.get("stop_sequence",""))
                    prev = trip_last.get((feed_name, tid))
                    candidate = (seq is not None, seq if seq is not None else -1, order, skey)
                    if prev is None or candidate[:3] > prev[:3]:
                        trip_last[(feed_name, tid)] = candidate

            for comp, cand in trip_last.items():
                hk = trip_info[comp]["headsign_key"]
                skey = cand[3]
                terminal_counts[hk][skey] += 1

    # terminal usage per stop across all headsigns
    stop_terminal_total = Counter()
    for c in terminal_counts.values():
        stop_terminal_total.update(c)

    return {
        "feeds": feeds,
        "stops": stops,
        "headsign_display": headsign_display,
        "terminal_counts": terminal_counts,
        "stop_terminal_total": stop_terminal_total,
    }

def excel_matrix(value):
    if value is None:
        return []
    if isinstance(value, tuple):
        if value and isinstance(value[0], tuple):
            return [list(r) for r in value]
        return [list(value)]
    return [[value]]

def norm_header(x):
    return normalize_spaces(str(x or "")).casefold()

def header_map(ws):
    used = ws.UsedRange
    vals = excel_matrix(used.Value2)
    if not vals:
        return {}
    return {norm_header(v): i+1 for i, v in enumerate(vals[0]) if v not in (None, "")}

def get_used_rows(ws):
    try:
        return int(ws.UsedRange.Rows.Count)
    except Exception:
        return 1

def ensure_headers(ws, headers):
    hm = header_map(ws)
    max_col = max(hm.values(), default=0)
    for h in headers:
        if norm_header(h) not in hm:
            max_col += 1
            ws.Cells(1, max_col).Value = h
            hm[norm_header(h)] = max_col
    return hm

def row_values(ws, row, hm, headers):
    out = {}
    for h in headers:
        col = hm.get(norm_header(h))
        out[h] = ws.Cells(row, col).Value if col else None
    return out

def set_cell(ws, row, header, hm, value):
    col = hm[norm_header(header)]
    ws.Cells(row, col).Value = value

def find_rows_by_key(ws, hm, key_header):
    col = hm[norm_header(key_header)]
    rows = {}
    last = get_used_rows(ws)
    for r in range(2, last + 1):
        v = ws.Cells(r, col).Value
        if v not in (None, ""):
            rows[str(v)] = r
    return rows

def last_data_row(ws, key_header):
    hm = header_map(ws)
    col = hm.get(norm_header(key_header))
    if not col:
        return 1
    last = get_used_rows(ws)
    while last > 1 and ws.Cells(last, col).Value in (None, ""):
        last -= 1
    return last

def set_maps_formula(ws, row, maps_col, lat_col, lon_col, label="APRI MAPS"):
    la = ws.Cells(row, lat_col).Value
    lo = ws.Cells(row, lon_col).Value
    url = maps_url(la, lo)
    if not url:
        ws.Cells(row, maps_col).Value = ""
        return
    # English Formula property works regardless of Italian Excel UI.
    ws.Cells(row, maps_col).Formula = f'=HYPERLINK("{url}","{label}")'

def clear_excess_format(ws, start_row, end_row, start_col=1, end_col=12):
    if end_row < start_row:
        return
    try:
        ws.Range(ws.Cells(start_row,start_col), ws.Cells(end_row,end_col)).ClearFormats()
    except Exception:
        pass

def apply_row_highlight(ws, row, status, last_col):
    rng = ws.Range(ws.Cells(row,1), ws.Cells(row,last_col))
    # Remove previous highlight.
    try:
        rng.Interior.Pattern = -4142  # xlNone
    except Exception:
        pass
    s = str(status or "").upper()
    if s == "NUOVO":
        rng.Interior.Color = 10092543  # light orange-ish
    elif s in {"RIATTIVATO","AGGIORNATO"}:
        rng.Interior.Color = 13431551  # light green-ish

def save_history(ws, action, key, google, override, default, status):
    last = get_used_rows(ws) + 1
    if last < 2:
        last = 2
    values = [datetime.now().strftime("%Y-%m-%d %H:%M:%S"), action, key, google or "", override or "", default or "", status or ""]
    for c, v in enumerate(values, 1):
        ws.Cells(last, c).Value = v

def open_excel_workbook():
    if win32 is None:
        raise RuntimeError("pywin32 non è installato. Esegui install_dependencies.bat")
    if not XLSX.exists():
        raise RuntimeError(f"Manca {XLSX.name} nella cartella del programma.")
    lock = XLSX.parent / ("~$" + XLSX.name)
    if lock.exists():
        raise RuntimeError(f"Excel sembra avere il file aperto. Chiudi completamente '{XLSX.name}' e riprova.")
    excel = win32.DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    wb = excel.Workbooks.Open(str(XLSX), UpdateLinks=0, ReadOnly=False)
    return excel, wb

def get_or_add_sheet(wb, name):
    for i in range(1, wb.Worksheets.Count + 1):
        if wb.Worksheets(i).Name == name:
            return wb.Worksheets(i)
    ws = wb.Worksheets.Add(After=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = name
    return ws

def format_sheet_headers(ws, color):
    last_col = ws.UsedRange.Columns.Count
    if last_col < 1: return
    rng = ws.Range(ws.Cells(1,1), ws.Cells(1,last_col))
    rng.Font.Bold = True
    rng.Font.Color = 0xFFFFFF
    rng.Interior.Color = color
    rng.WrapText = True
    ws.Rows(1).RowHeight = 32

def configure_columns(ws, widths):
    for col, width in widths.items():
        ws.Columns(col).ColumnWidth = width

def _bulk_sheet_values(ws):
    """Read the entire used range with ONE COM call."""
    used = ws.UsedRange
    vals = excel_matrix(used.Value2)
    if not vals:
        return [[None]]
    # Excel returns a scalar for a one-cell UsedRange.
    return vals


def _header_map_from_matrix(matrix):
    if not matrix:
        return {}
    return {norm_header(v): i+1 for i, v in enumerate(matrix[0]) if v not in (None, "")}


def _cell_value(row, col):
    if col <= 0 or col > len(row):
        return None
    return row[col-1]


def _set_matrix_value(row, col, value):
    while len(row) < col:
        row.append(None)
    row[col-1] = value


def _write_matrix(ws, start_row, matrix, end_col):
    if not matrix:
        return
    # COM receives the whole 2D matrix at once, instead of thousands of Cells() calls.
    ws.Range(ws.Cells(start_row, 1), ws.Cells(start_row + len(matrix) - 1, end_col)).Value2 = matrix


def _write_formula_column(ws, start_row, formulas, col):
    if not formulas:
        return
    vals = [[f] for f in formulas]
    ws.Range(ws.Cells(start_row, col), ws.Cells(start_row + len(formulas) - 1, col)).Formula = vals


def _apply_status_formatting(ws, last_row, last_col):
    """Conditional formatting limited strictly to the actual data rows."""
    if last_row < 2:
        return
    rng = ws.Range(ws.Cells(2, 1), ws.Cells(last_row, last_col))
    try:
        rng.FormatConditions.Delete()
    except Exception:
        pass
    status_col = last_col - 4 if last_col == len(HEADSIGN_HEADERS) else 9
    # Status column is H for headsigns, I for stops.
    status_col = 8 if last_col == len(HEADSIGN_HEADERS) else 9
    try:
        fc = rng.FormatConditions.Add(Type=1, Formula1=f'=UPPER(${chr(64+status_col)}2)="NUOVO"')
        fc.Interior.Color = 10092543
        fc.StopIfTrue = False
        fc = rng.FormatConditions.Add(Type=1, Formula1=f'=OR(UPPER(${chr(64+status_col)}2)="RIATTIVATO",UPPER(${chr(64+status_col)}2)="AGGIORNATO")')
        fc.Interior.Color = 13431551
        fc.StopIfTrue = False
    except Exception:
        pass


def _prepare_sheet_rows(ws, headers, key_header):
    """Return (header map, rows, key->row-index) using one UsedRange read."""
    matrix = _bulk_sheet_values(ws)
    hm = _header_map_from_matrix(matrix)
    # The template is expected to contain the headers. Add missing headers in one write where possible.
    missing = [h for h in headers if norm_header(h) not in hm]
    if missing:
        next_col = max(hm.values(), default=0) + 1
        for h in missing:
            ws.Cells(1, next_col).Value2 = h
            hm[norm_header(h)] = next_col
            next_col += 1
        matrix = _bulk_sheet_values(ws)
        hm = _header_map_from_matrix(matrix)
    rows = matrix[1:] if len(matrix) > 1 else []
    key_col = hm[norm_header(key_header)]
    key_rows = {}
    for idx, row in enumerate(rows, start=2):
        v = _cell_value(row, key_col)
        if v not in (None, ""):
            key_rows[str(v)] = idx
    return hm, rows, key_rows


def _clear_sheet_data_and_format(ws):
    """Clear the whole visible data area so old feed grouping/formatting never survives a refresh."""
    try:
        used = ws.UsedRange
        last_row = max(int(used.Row + used.Rows.Count - 1), 1)
        last_col = max(int(used.Column + used.Columns.Count - 1), len(HEADSIGN_HEADERS))
    except Exception:
        last_row, last_col = 2000, len(HEADSIGN_HEADERS)
    try:
        ws.Range(ws.Cells(1, 1), ws.Cells(last_row, last_col)).Clear()
    except Exception:
        pass


def _style_feed_header(ws, row, feed_name, last_col):
    rng = ws.Range(ws.Cells(row, 1), ws.Cells(row, last_col))
    rng.Merge()
    cell = ws.Cells(row, 1)
    cell.Value = f"FEED · {feed_name}"
    cell.Font.Bold = True
    cell.Font.Size = 11
    cell.Font.Color = 0xFFFFFF
    cell.Interior.Color = 0x5B6573
    cell.HorizontalAlignment = -4131  # xlLeft
    cell.VerticalAlignment = -4108    # xlCenter
    rng.RowHeight = 24


def _style_section_header(ws, row, last_col):
    rng = ws.Range(ws.Cells(row, 1), ws.Cells(row, last_col))
    rng.Font.Bold = True
    rng.Font.Color = 0xFFFFFF
    rng.Interior.Color = 0x784A00
    rng.WrapText = True
    rng.HorizontalAlignment = -4108
    rng.VerticalAlignment = -4108
    ws.Rows(row).RowHeight = 32


def update_mapping():
    # GTFS parsing happens once in Python. Excel is used only for one bulk rewrite.
    data = collect_gtfs()
    excel, wb = open_excel_workbook()
    try:
        sh = get_or_add_sheet(wb, "Mappatura Headsign")
        ss = get_or_add_sheet(wb, "Tutte le fermate")
        hist = get_or_add_sheet(wb, "Storico")
        ensure_headers(hist, HISTORY_HEADERS)

        # Read the existing mappings before rebuilding the visible sheet.
        old_hm = header_map(sh)
        old_vals = _bulk_sheet_values(sh)
        old_rows = old_vals[1:] if len(old_vals) > 1 else []
        old_hk_col = old_hm.get(norm_header("Binding Key"))
        old_map = {}
        if old_hk_col:
            for row in old_rows:
                key = _cell_value(row, old_hk_col)
                if key not in (None, ""):
                    old_map[str(key)] = {
                        h: _cell_value(row, old_hm.get(norm_header(h), 0)) if old_hm.get(norm_header(h)) else None
                        for h in HEADSIGN_HEADERS
                    }

        # Preserve stop sheet as before; it is a separate operational registry.
        sm, srows, stop_existing = _prepare_sheet_rows(ss, STOP_HEADERS, "Stop Binding Key")
        hist_matrix = _bulk_sheet_values(hist)
        hist_rows_existing = max(len(hist_matrix), 1)

        # Build the global headsign records first, keyed only by canonical binding.
        active_keys = set(data["headsign_display"])
        records = {}
        now_date = datetime.now().strftime("%Y-%m-%d")
        history_add = []
        new_count = 0
        reactivated = 0

        for hk, display in data["headsign_display"].items():
            counts = data["terminal_counts"].get(hk, Counter())
            terminal_key, _ = counts.most_common(1)[0] if counts else (None, 0)
            term = data["stops"].get(terminal_key, {}) if terminal_key else {}
            old = old_map.get(hk, {})
            old_status = str(old.get("Stato") or "").upper()
            status = "NUOVO" if not old else ("RIATTIVATO" if old_status == "INATTIVO" else ("NUOVO" if old_status == "NUOVO" else "ATTIVO"))
            if status == "RIATTIVATO":
                reactivated += 1
            elif not old:
                new_count += 1
            records[hk] = {
                "google": display,
                "override": old.get("Apple trip_headsign (Override)"),
                "default": smart_title_case(display),
                "terminal": term.get("default_name", "") if terminal_key else "",
                "lat": term.get("lat") if terminal_key else "",
                "lon": term.get("lon") if terminal_key else "",
                "status": status,
                "first": old.get("Prima rilevazione") or now_date,
                "last": now_date,
                "note": old.get("Note") or "",
                "key": hk,
            }
            if status in {"NUOVO", "RIATTIVATO"}:
                history_add.append([
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"), status, hk, display,
                    old.get("Apple trip_headsign (Override)") or "", smart_title_case(display), status
                ])

        # Group each headsign by the feed(s) where it occurs. The binding itself is global.
        headsign_feeds = defaultdict(list)
        for feed in data["feeds"]:
            feed_name = feed.name
            with zipfile.ZipFile(feed, "r") as z:
                trip_rows, _ = read_csv_from_zip(z, "trips.txt")
                seen = set()
                for r in trip_rows:
                    hk = canonical(str(r.get("trip_headsign", "") or "").strip())
                    if hk in records and hk not in seen:
                        headsign_feeds[hk].append(feed_name)
                        seen.add(hk)

        # Rebuild the visible headsign sheet from scratch, in feed order.
        _clear_sheet_data_and_format(sh)
        sh.Range(sh.Cells(1,1), sh.Cells(1,len(HEADSIGN_HEADERS))).Value2 = [HEADSIGN_HEADERS]
        _style_section_header(sh, 1, len(HEADSIGN_HEADERS))
        configure_columns(sh, {"A":34,"B":34,"C":34,"D":34,"E":12,"F":12,"G":14,"H":14,"I":18,"J":18,"K":28,"L":42})
        try:
            sh.Columns(12).Hidden = True  # Binding Key
        except Exception:
            pass

        visible_rows = []
        row_statuses = []
        current_row = 2
        group_blocks = []
        seen_global = set()

        for feed in data["feeds"]:
            feed_name = feed.name
            group_keys = [hk for hk in records if feed_name in headsign_feeds.get(hk, [])]
            group_keys.sort(key=lambda hk: records[hk]["google"].casefold())
            if not group_keys:
                continue

            _style_feed_header(sh, current_row, feed_name, len(HEADSIGN_HEADERS))
            current_row += 1
            block_start = current_row
            for hk in group_keys:
                rec = records[hk]
                override = rec["override"]
                # Only the first occurrence of a binding is considered editable data;
                # repeated feed sections show the same global mapping read-only-looking but usable.
                visible_rows.append([
                    rec["google"], override or "", rec["default"], rec["terminal"], rec["lat"], rec["lon"],
                    None, rec["status"], rec["first"], rec["last"], rec["note"], rec["key"]
                ])
                row_statuses.append(rec["status"])
                seen_global.add(hk)
                current_row += 1
            group_blocks.append((block_start, current_row - 1))
            current_row += 2  # visual breathing room between feeds

        # Append historical/inactive bindings after the feed groups, still in the same worksheet.
        inactive = [hk for hk in old_map if hk not in active_keys and hk not in seen_global]
        if inactive:
            current_row += 1
            _style_feed_header(sh, current_row, "STORICO · HEADSIGN NON PIÙ PRESENTI", len(HEADSIGN_HEADERS))
            current_row += 1
            for hk in sorted(inactive, key=lambda k: str(old_map[k].get("Google trip_headsign") or k).casefold()):
                old = old_map[hk]
                visible_rows.append([
                    old.get("Google trip_headsign") or hk,
                    old.get("Apple trip_headsign (Override)") or "",
                    old.get("Default Apple · Title Case") or smart_title_case(str(old.get("Google trip_headsign") or "")),
                    old.get("Fermata terminale più frequente") or "",
                    old.get("Lat") or "", old.get("Lon") or "", None, "INATTIVO",
                    old.get("Prima rilevazione") or "", old.get("Ultima rilevazione") or "", old.get("Note") or "", hk
                ])
                row_statuses.append("INATTIVO")
                current_row += 1

        # Write only actual visible rows. Blank spacer rows remain genuinely blank.
        if visible_rows:
            # The rows were built in feed order; write them starting after the first header.
            write_start = 2
            sh.Range(sh.Cells(write_start,1), sh.Cells(write_start + len(visible_rows) - 1, len(HEADSIGN_HEADERS))).Value2 = visible_rows
            # Maps formulas in the visible rows.
            maps_formulas = []
            for row in visible_rows:
                u = maps_url(row[4], row[5])
                maps_formulas.append([f'=HYPERLINK("{u}","APRI MAPS")' if u else '=""'])
            sh.Range(sh.Cells(write_start,7), sh.Cells(write_start + len(maps_formulas) - 1,7)).Formula = maps_formulas

        # The grouped headers above are overwritten if bulk-write spans across them; re-render feed labels
        # after the data write. This also makes the spacer layout deterministic.
        # To avoid collision, rebuild row-by-row from a precomputed layout in a second compact pass.
        _clear_sheet_data_and_format(sh)
        # Header row
        sh.Range(sh.Cells(1,1), sh.Cells(1,len(HEADSIGN_HEADERS))).Value2 = [HEADSIGN_HEADERS]
        _style_section_header(sh, 1, len(HEADSIGN_HEADERS))
        current_row = 2
        data_rows_written = 0
        for feed in data["feeds"]:
            feed_name = feed.name
            group_keys = [hk for hk in records if feed_name in headsign_feeds.get(hk, [])]
            group_keys.sort(key=lambda hk: records[hk]["google"].casefold())
            if not group_keys:
                continue
            _style_feed_header(sh, current_row, feed_name, len(HEADSIGN_HEADERS))
            current_row += 1
            rows = []
            formulas = []
            for hk in group_keys:
                rec = records[hk]
                rows.append([
                    rec["google"], rec["override"] or "", rec["default"], rec["terminal"], rec["lat"], rec["lon"], None,
                    rec["status"], rec["first"], rec["last"], rec["note"], rec["key"]
                ])
                u = maps_url(rec["lat"], rec["lon"])
                formulas.append([f'=HYPERLINK("{u}","APRI MAPS")' if u else '=""'])
            end_row = current_row + len(rows) - 1
            sh.Range(sh.Cells(current_row,1), sh.Cells(end_row,len(HEADSIGN_HEADERS))).Value2 = rows
            sh.Range(sh.Cells(current_row,7), sh.Cells(end_row,7)).Formula = formulas
            current_row = end_row + 1 + 2
        # Historical section
        inactive = [hk for hk in old_map if hk not in active_keys]
        if inactive:
            _style_feed_header(sh, current_row, "STORICO · HEADSIGN NON PIÙ PRESENTI", len(HEADSIGN_HEADERS))
            current_row += 1
            rows=[]; formulas=[]
            for hk in sorted(inactive, key=lambda k: str(old_map[k].get("Google trip_headsign") or k).casefold()):
                old=old_map[hk]
                rows.append([
                    old.get("Google trip_headsign") or hk, old.get("Apple trip_headsign (Override)") or "",
                    old.get("Default Apple · Title Case") or smart_title_case(str(old.get("Google trip_headsign") or "")),
                    old.get("Fermata terminale più frequente") or "", old.get("Lat") or "", old.get("Lon") or "", None,
                    "INATTIVO", old.get("Prima rilevazione") or "", old.get("Ultima rilevazione") or "", old.get("Note") or "", hk
                ])
                u=maps_url(old.get("Lat"), old.get("Lon"))
                formulas.append([f'=HYPERLINK("{u}","APRI MAPS")' if u else '=""'])
            if rows:
                end_row=current_row+len(rows)-1
                sh.Range(sh.Cells(current_row,1),sh.Cells(end_row,len(HEADSIGN_HEADERS))).Value2=rows
                sh.Range(sh.Cells(current_row,7),sh.Cells(end_row,7)).Formula=formulas
                current_row=end_row+1

        h_last = current_row - 1

        # Stops: preserve the existing efficient bulk behavior, but keep current layout unchanged.
        cols_s = max(len(STOP_HEADERS), max(sm.values(), default=0))
        while any(len(r) < cols_s for r in srows):
            for r in srows:
                while len(r) < cols_s: r.append(None)
        current_stop_keys = set(data["stops"])
        for sk, info in data["stops"].items():
            if sk in stop_existing:
                excel_row = stop_existing[sk]; row = srows[excel_row-2]
                old_status = str(_cell_value(row, sm["stato"]) or "").upper()
                status = "RIATTIVATO" if old_status == "INATTIVO" else ("NUOVO" if old_status == "NUOVO" else "ATTIVO")
            else:
                row=[None]*cols_s; srows.append(row); stop_existing[sk]=len(srows)+1; status="NUOVO"
            def sv(name,value): _set_matrix_value(row,sm[name],value)
            sv("stop binding key",sk); sv("stop id",info.get("stop_id")); sv("nome originale",info.get("original_name")); sv("default apple stop_name",info.get("default_name")); sv("lat",info.get("lat")); sv("lon",info.get("lon")); sv("stato",status); sv("feed","; ".join(sorted(info.get("feeds",[])))); sv("occorrenze terminali",data["stop_terminal_total"].get(sk,0))
        for sk, excel_row in stop_existing.items():
            if sk not in current_stop_keys and excel_row>=2:
                _set_matrix_value(srows[excel_row-2], sm["stato"], "INATTIVO")
        s_last=len(srows)+1
        _write_matrix(ss,2,srows,cols_s)
        s_maps=[maps_url(_cell_value(r,sm["lat"]),_cell_value(r,sm["lon"])) for r in srows]
        _write_formula_column(ss,2,[f'=HYPERLINK("{u}","APRI MAPS")' if u else '=""' for u in s_maps],sm["maps"])
        format_sheet_headers(ss,0x527A36)
        configure_columns(ss,{"A":44,"B":20,"C":34,"D":34,"E":34,"F":12,"G":12,"H":14,"I":14,"J":28,"K":18,"L":28})
        _apply_status_formatting(ss,s_last,len(STOP_HEADERS))

        # HeadSign formatting: compact, readable, with true blank spacer rows.
        configure_columns(sh,{"A":34,"B":34,"C":34,"D":34,"E":12,"F":12,"G":14,"H":14,"I":18,"J":18,"K":28,"L":42})
        _apply_status_formatting(sh,h_last,len(HEADSIGN_HEADERS))
        try:
            sh.Columns(12).Hidden=True
            sh.Activate(); sh.Application.ActiveWindow.SplitRow=1; sh.Application.ActiveWindow.FreezePanes=True
        except Exception:
            pass
        try:
            sh.Range(sh.Cells(2,1),sh.Cells(h_last,len(HEADSIGN_HEADERS))).WrapText=True
            sh.Rows("2:"+str(h_last)).RowHeight=21
        except Exception:
            pass
        format_sheet_headers(hist,0x00607A)
        if history_add:
            hist_start=max(hist_rows_existing,1)+1
            _write_matrix(hist,hist_start,history_add,len(HISTORY_HEADERS))

        wb.Save()
        print(f"Mappatura aggiornata: {len(active_keys)} headsign attivi; {new_count} nuovi; {reactivated} riattivati.")
        print("Foglio unico 'Mappatura Headsign': headsign raggruppati per feed con separatori e spazio verticale.")
        print("I binding restano globali e persistenti: sostituire/rinominare gli ZIP non richiede ricompilazione.")
        print("Default Apple = Google trip_headsign in Title Case; l'Override Apple sostituisce il default quando compilato.")
        print("Per ogni headsign: ultima fermata di ogni corsa (stop_sequence massimo), poi terminale più frequente. Maps usa solo coordinate.")
    finally:
        wb.Close(SaveChanges=True)
        excel.Quit()

def generate_apple():
    # Excel must be closed because we need to read overrides and write the workbook after generation.
    excel, wb = open_excel_workbook()
    try:
        sh = get_or_add_sheet(wb, "Mappatura Headsign")
        ss = get_or_add_sheet(wb, "Tutte le fermate")
        hm = ensure_headers(sh, HEADSIGN_HEADERS)
        sm = ensure_headers(ss, STOP_HEADERS)

        headsign_map = {}
        for r in range(2, get_used_rows(sh)+1):
            g = sh.Cells(r, hm[norm_header("Google trip_headsign")]).Value
            if not g:
                continue
            hk = canonical(str(g))
            override = sh.Cells(r, hm[norm_header("Apple trip_headsign (Override)")]).Value
            default = sh.Cells(r, hm[norm_header("Default Apple · Title Case")]).Value or smart_title_case(str(g))
            final = str(override).strip() if override not in (None, "") and str(override).strip() else str(default)
            headsign_map[hk] = final

        # Stop overrides: key -> override/default.
        stop_map = {}
        for r in range(2, get_used_rows(ss)+1):
            sk = ss.Cells(r, sm[norm_header("Stop Binding Key")]).Value
            if not sk:
                continue
            ov = ss.Cells(r, sm[norm_header("Apple stop_name (Override)")]).Value
            default = ss.Cells(r, sm[norm_header("Default Apple stop_name")]).Value
            final = str(ov).strip() if ov not in (None, "") and str(ov).strip() else str(default or "")
            stop_map[str(sk)] = final

        # Block generation if any active headsign has no default/override.
        missing = []
        for r in range(2, get_used_rows(sh)+1):
            status = str(sh.Cells(r, hm[norm_header("Stato")]).Value or "").upper()
            g = sh.Cells(r, hm[norm_header("Google trip_headsign")]).Value
            if status != "INATTIVO" and g and not headsign_map.get(canonical(str(g)), "").strip():
                missing.append(str(g))
        if missing:
            raise RuntimeError("Mappature Apple mancanti: " + ", ".join(missing[:20]))

        feeds = list_feeds()
        if not feeds:
            raise RuntimeError(f"Nessun ZIP trovato in: {BASE_DIR}")
        ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_archive = ARCHIVE_DIR / stamp
        run_archive.mkdir(parents=True, exist_ok=True)

        # Archive current Apple ZIPs first.
        for old in APPLE_DIR.glob("*.zip"):
            shutil.move(str(old), str(run_archive / old.name))

        generated = 0
        for feed in feeds:
            out = APPLE_DIR / feed.name
            tmp = APPLE_DIR / (feed.stem + "__tmp.zip")
            with zipfile.ZipFile(feed, "r") as zin, zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as zout:
                # We need local stop map per feed to transform stops.txt.
                local_stops = {}
                for info in zin.infolist():
                    name = info.filename
                    data = zin.read(info)
                    if name == "trips.txt":
                        text = data.decode("utf-8-sig", errors="replace")
                        rows = list(csv.DictReader(io.StringIO(text, newline="")))
                        fieldnames = list(rows[0].keys()) if rows else []
                        output = io.StringIO(newline="")
                        writer = csv.DictWriter(output, fieldnames=fieldnames, lineterminator="\n")
                        writer.writeheader()
                        for row in rows:
                            g = str(row.get("trip_headsign","") or "")
                            row["trip_headsign"] = headsign_map.get(canonical(g), smart_title_case(g))
                            writer.writerow(row)
                        data = output.getvalue().encode("utf-8")
                    elif name == "stops.txt":
                        text = data.decode("utf-8-sig", errors="replace")
                        rows = list(csv.DictReader(io.StringIO(text, newline="")))
                        fieldnames = list(rows[0].keys()) if rows else []
                        output = io.StringIO(newline="")
                        writer = csv.DictWriter(output, fieldnames=fieldnames, lineterminator="\n")
                        writer.writeheader()
                        for row in rows:
                            sid = str(row.get("stop_id","")).strip()
                            lat = parse_float(row.get("stop_lat",""))
                            lon = parse_float(row.get("stop_lon",""))
                            sk = stop_key(feed.name, sid, lat, lon)
                            default = smart_title_case(row.get("stop_name", ""))
                            row["stop_name"] = stop_map.get(sk, default)
                            writer.writerow(row)
                        data = output.getvalue().encode("utf-8")
                    zout.writestr(info, data)
            tmp.replace(out)
            generated += 1

        wb.Save()
        print(f"Generati {generated} feed Apple in: {APPLE_DIR}")
        print(f"Versione precedente archiviata in: {run_archive}")
        print("Applicati solo trip_headsign e stop_name; gli altri contenuti dei GTFS vengono copiati invariati.")
    finally:
        wb.Close(SaveChanges=True)
        excel.Quit()

def main():
    # Full GUI restored. The processing engine remains the same.
    import threading
    import tkinter as tk
    from tkinter import ttk, messagebox

    class Tee:
        def __init__(self, widget):
            self.widget = widget
        def write(self, text):
            if not text:
                return
            try:
                self.widget.after(0, self._append, text)
            except Exception:
                pass
        def flush(self):
            pass
        def _append(self, text):
            self.widget.configure(state="normal")
            self.widget.insert("end", text)
            self.widget.see("end")
            self.widget.configure(state="disabled")

    root = tk.Tk()
    root.title(f"GTFS Apple HeadSign Manager v{VERSION}")
    root.geometry("920x650")
    root.minsize(780, 560)

    style = ttk.Style(root)
    try:
        style.theme_use("vista")
    except Exception:
        pass
    style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
    style.configure("Subtitle.TLabel", font=("Segoe UI", 10))
    style.configure("Big.TButton", font=("Segoe UI", 12, "bold"), padding=(16, 12))
    style.configure("Status.TLabel", font=("Segoe UI", 10, "bold"))

    top = ttk.Frame(root, padding=(22, 18, 22, 10))
    top.pack(fill="x")
    ttk.Label(top, text="GTFS Apple HeadSign Manager", style="Title.TLabel").pack(anchor="w")
    ttk.Label(
        top,
        text=f"Google GTFS → Apple Maps ready  ·  v{VERSION}",
        style="Subtitle.TLabel"
    ).pack(anchor="w", pady=(3, 0))

    info = ttk.LabelFrame(root, text="Cartelle", padding=12)
    info.pack(fill="x", padx=22, pady=(4, 10))
    ttk.Label(info, text=f"Base GTFS:  {BASE_DIR}").pack(anchor="w")
    ttk.Label(info, text=f"Apple:      {APPLE_DIR}").pack(anchor="w", pady=(3, 0))
    ttk.Label(info, text=f"Excel:      {XLSX}").pack(anchor="w", pady=(3, 0))

    actions = ttk.Frame(root, padding=(22, 2, 22, 10))
    actions.pack(fill="x")
    actions.columnconfigure((0, 1, 2), weight=1)

    log_frame = ttk.LabelFrame(root, text="Log", padding=8)
    log_frame.pack(fill="both", expand=True, padx=22, pady=(0, 10))
    log = tk.Text(log_frame, height=18, wrap="word", font=("Consolas", 10), state="disabled")
    scroll = ttk.Scrollbar(log_frame, orient="vertical", command=log.yview)
    log.configure(yscrollcommand=scroll.set)
    log.pack(side="left", fill="both", expand=True)
    scroll.pack(side="right", fill="y")

    footer = ttk.Frame(root, padding=(22, 0, 22, 18))
    footer.pack(fill="x")
    status_var = tk.StringVar(value="Pronto")
    status_label = ttk.Label(footer, textvariable=status_var, style="Status.TLabel")
    status_label.pack(side="left")

    original_stdout = sys.stdout
    tee = Tee(log)
    sys.stdout = tee

    running = {"value": False}

    def set_running(v):
        running["value"] = v
        state = "disabled" if v else "normal"
        btn_update.configure(state=state)
        btn_generate.configure(state=state)
        btn_excel.configure(state=state)
        btn_base.configure(state=state)
        btn_apple.configure(state=state)
        status_var.set("Elaborazione in corso…" if v else "Pronto")

    def run_task(label, fn):
        if running["value"]:
            return
        def worker():
            # pywin32/COM must be initialized explicitly because update_mapping() and
            # generate_apple() run in this background thread rather than the main GUI thread.
            pythoncom = None
            com_initialized = False
            try:
                import pythoncom
                pythoncom.CoInitialize()
                com_initialized = True
            except Exception:
                # If pywin32 is unavailable, the operation will report the normal
                # dependency error from open_excel_workbook().
                pythoncom = None

            set_running(True)
            print(f"\n[{datetime.now().strftime('%H:%M:%S')}] {label}")
            try:
                fn()
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Operazione completata.")
            except Exception as e:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ERRORE: {e}")
                root.after(0, lambda err=str(e): messagebox.showerror("Errore", err))
            finally:
                if com_initialized and pythoncom is not None:
                    try:
                        pythoncom.CoUninitialize()
                    except Exception:
                        pass
                root.after(0, lambda: set_running(False))
        threading.Thread(target=worker, daemon=True).start()

    def open_path(path):
        try:
            os.startfile(str(path))
        except Exception as e:
            messagebox.showerror("Errore", str(e))

    def open_excel():
        if not XLSX.exists():
            messagebox.showwarning("Excel", "Mappa_Headsign.xlsx non esiste ancora. Premi prima 'Aggiorna Mappatura'.")
            return
        open_path(XLSX)

    btn_update = ttk.Button(
        actions, text="🔄  AGGIORNA MAPPATURA", style="Big.TButton",
        command=lambda: run_task("Aggiornamento mappatura", update_mapping)
    )
    btn_update.grid(row=0, column=0, sticky="ew", padx=(0, 6))

    btn_generate = ttk.Button(
        actions, text="🍎  GENERA APPLE", style="Big.TButton",
        command=lambda: run_task("Generazione feed Apple", generate_apple)
    )
    btn_generate.grid(row=0, column=1, sticky="ew", padx=6)

    btn_excel = ttk.Button(actions, text="📊  APRI EXCEL", command=open_excel)
    btn_excel.grid(row=0, column=2, sticky="ew", padx=(6, 0))

    btn_base = ttk.Button(actions, text="📁  APRI BASE GTFS", command=lambda: open_path(BASE_DIR))
    btn_base.grid(row=1, column=0, sticky="ew", padx=(0, 6), pady=(8, 0))
    btn_apple = ttk.Button(actions, text="📦  APRI CARTELLA APPLE", command=lambda: open_path(APPLE_DIR))
    btn_apple.grid(row=1, column=1, sticky="ew", padx=6, pady=(8, 0))
    ttk.Button(actions, text="🧹  SVUOTA LOG", command=lambda: (log.configure(state="normal"), log.delete("1.0", "end"), log.configure(state="disabled"))).grid(row=1, column=2, sticky="ew", padx=(6, 0), pady=(8, 0))

    # Initial log state.
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Pronto. Metti i feed Google in 'Base GTFS'.")
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Excel: B = Override Apple facoltativo; C = Default Title Case automatico.")
    print(f"[{datetime.now().strftime('%H:%M:%S')}] E = Maps con sole coordinate. Dopo la modifica dell'Excel, chiudilo prima di generare.")

    def on_close():
        if running["value"]:
            if not messagebox.askyesno("Operazione in corso", "Un'operazione è ancora in corso. Chiudere comunque?"):
                return
        sys.stdout = original_stdout
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()

if __name__ == "__main__":
    main()
