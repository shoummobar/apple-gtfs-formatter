@echo off
title Installazione GTFS Apple HeadSign Manager
py -m pip install --upgrade pywin32
py -m pywin32_postinstall -install
echo.
echo Installazione completata.
pause
